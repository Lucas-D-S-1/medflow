/**
 * Visão regional.
 *
 * Onde está o sinal e como ele evolui: mapa por percentis, série mensal
 * e sazonalidade.
 */

import { expect, test } from '@playwright/test'
import {
  coberturaMetodologia,
  iphDaMacro3529,
  methodologySnapshot,
  competenciaVisivel,
  escolherCompetencia,
  mockLiveSource,
  paginacao,
  pt,
  regiaoDestacada,
  regionalSeriesSnapshot,
  regionalSnapshot,
  serieRegionalAtual,
  snapshotCompetencia,
  snapshotCompetenciaBR,
  statusSnapshot,
} from './apoio'

test('renderiza a competência e a versão do contrato recebidas do Oracle', async ({ page }) => {
  await page.route('**/api/dev/v1/status', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...statusSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })
  await page.route('**/api/dev/v1/metodologia', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...methodologySnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })
  await page.route('**/api/dev/v1/regioes/resumo**', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...regionalSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })

  await page.goto('/?regiao=35073')

  // Contrato e origem prestam contas apenas em Metodologia.
  await expect(page.getByTestId('source-badge')).toHaveCount(0)
  await expect(page.getByTestId('data-through')).toHaveCount(0)
  await expect(page.getByTestId('contract-version')).toHaveCount(0)
  await expect(page.getByTestId('regional-context-note')).toContainText(snapshotCompetenciaBR)
  await expect(page.getByTestId('regional-count')).toHaveText('62 de 62 regiões')
  await expect.poll(() => competenciaVisivel(page)).toBe(snapshotCompetencia)
  await expect(page.getByTestId('regional-map-svg')).toHaveCount(1)
  await expect(page.locator('.regional-map-shape')).toHaveCount(62)
  await expect(page.getByTestId('regional-selected-name')).toHaveText('JUNDIAI')
  await expect(page.getByLabel('Rede Regional de Atenção à Saúde')).toContainText(
    'Rede regional 16 — Bragança e Jundiaí',
  )
  // Os números da região selecionada moram no cartão do mapa. Eles também
  // apareciam num quadro logo abaixo, repetidos, que saiu por isso.
  const cartao = page.getByTestId('regional-map-tooltip')
  await expect(cartao).toContainText(pt(regiaoDestacada.new_admissions as number))
  await expect(cartao).toContainText(`${pt(regiaoDestacada.iph_percent as number, 1)}%`)
  await expect(cartao).toContainText(`${pt(regiaoDestacada.tmh_percent as number, 1)}%`)
  await expect(cartao).toContainText(
    `${pt(regiaoDestacada.ipe_above_reference as number)} de ${pt(regiaoDestacada.ipe_eligible_pairs as number)}`,
  )


  await page.getByRole('link', { name: 'Metodologia' }).click()
  await expect(page.getByTestId('methodology-data-through')).toContainText(`Gold publicada até ${snapshotCompetenciaBR}`)
  await expect(page.getByTestId('coverage-regions')).toHaveText('62')
  await expect(page.getByTestId('coverage-competencies')).toHaveText(
    String(coberturaMetodologia.competencies),
  )
  await expect(page.getByTestId('coverage-admissions')).toHaveText(
    pt(coberturaMetodologia.new_admissions),
  )
  await expect(page.getByTestId('coverage-patient-days')).toHaveText(
    pt(coberturaMetodologia.estimated_patient_days),
  )
  await expect(page.getByTestId('coverage-stay-days')).toHaveText(
    pt(coberturaMetodologia.stay_days),
  )
  await expect(
    page.getByRole('heading', { name: 'Por que Oracle neste MVP?' }),
  ).toBeVisible()
  await expect(page.locator('.database-decision')).toContainText('25 / 25')
  await expect(page.getByTestId('gold-updated-at')).toContainText('2026')
  await expect(page.getByTestId('formula-cmi')).toContainText('fator de correção IPCA')
  await expect(page.getByTestId('formula-iph')).toContainText('Pressão estimada sobre capacidade declarada, não ocupação física real.')
  await expect(page.getByTestId('cut-ipr')).toContainText('20 casos hospital/CID')
  await expect(page.getByTestId('reconciliation-new_admissions_cross_mart')).toContainText('diferença: 0')
  await expect(page.getByTestId('definition-billed_daily')).toContainText('QT_DIARIAS')
  await expect(page.getByTestId('state-benchmark_zero')).toContainText('IPR fica nulo')
  await expect(page.getByTestId('state-iph_denominator_zero')).toContainText('não imputa capacidade')
  await expect(page.getByTestId('territorial-hierarchy')).toContainText(
    'Rede Regional de Atenção à Saúde (RRAS)',
  )
})
test('filtra a competência sem abandonar o mapa espacial e o tamanho da amostra', async ({ page }) => {
  await page.route('**/api/dev/v1/status', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...statusSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })
  await page.route('**/api/dev/v1/metodologia', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...methodologySnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })

  let requestedCompetence = ''
  await page.route('**/api/dev/v1/regioes/resumo**', async (route) => {
    const requestUrl = new URL(route.request().url())
    const year = Number(requestUrl.searchParams.get('ano') ?? '2026')
    const month = Number(requestUrl.searchParams.get('mes') ?? '5')
    const competence = `${year}-${String(month).padStart(2, '0')}`
    // MoM e YoY pedem a competência anterior e o mesmo mês do ano anterior no
    // mesmo endpoint. O que este teste observa é a competência escolhida.
    if (competence >= '2025-05') requestedCompetence = competence
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...regionalSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
        data_through: requestedCompetence,
        filters: {
          year,
          month,
          macroregion_code: null,
          region_code: null,
        },
      }),
    })
  })

  await page.goto('/?regiao=35073')
  await expect.poll(() => competenciaVisivel(page)).toBe(snapshotCompetencia)
  await escolherCompetencia(page, '2025-05')

  await expect.poll(() => requestedCompetence).toBe('2025-05')
  await expect(page.getByTestId('regional-context-note')).toContainText('05/2025')
  await expect(page.locator('.regional-map-shape')).toHaveCount(62)
  // A amostra da região continua visível no cartão do mapa, que é onde os
  // números da região selecionada passaram a viver.
  await expect(page.getByTestId('regional-map-tooltip')).toContainText(
    pt(regiaoDestacada.new_admissions as number),
  )
})
test('expõe o mapa com percentis, seleção textual e uma única parada de tabulação', async ({ page }) => {
  await mockLiveSource(page)
  await page.route('**/api/dev/v1/regioes/resumo**', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...regionalSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })

  await page.goto('/regional?regiao=35073')

  // O mapa abre colorido pelo placar de sinais. Este teste é sobre a escala por
  // percentis do IPH, então ele declara o indicador que exercita.
  await page.getByTestId('map-metric-iph').click()

  const map = page.getByTestId('regional-map-svg')
  await expect(map).not.toHaveAttribute('role', 'img')
  await expect(map.locator('[role="button"]')).toHaveCount(62)
  await expect(map.locator('[tabindex="0"]')).toHaveCount(1)
  await expect(page.getByTestId('regional-map-legend')).toContainText('mínimo real')
  await expect(page.getByTestId('regional-map-legend')).toContainText('máximo real')
  await expect(page.getByTestId('regional-map-legend')).toContainText('Escala visual relativa por percentis')
  await expect(page.getByTestId('regional-map-selection')).toContainText('Selecionada: JUNDIAI')

  const initialButton = map.locator('[tabindex="0"]')
  await initialButton.focus()
  await initialButton.press('ArrowRight')
  await expect(map.locator('[tabindex="0"]')).toHaveCount(1)
  await expect(page.getByTestId('regional-map-selection')).not.toContainText('JUNDIAI')

  await page.goto('/regional?macrorregiao=3529&regiao=35102')
  // Navegar recomeça no placar de sinais, que é o padrão do mapa.
  await page.getByTestId('map-metric-iph').click()
  await expect(page.getByTestId('regional-count')).toHaveText('4 de 62 regiões')
  await expect(page.getByTestId('regional-map-svg').locator('[role="button"]')).toHaveCount(4)
  await expect(page.getByTestId('regional-map-legend')).toContainText(
    `mínimo real ${pt(Math.min(...iphDaMacro3529), 1)}%`,
  )
  await expect(page.getByTestId('regional-map-legend')).toContainText(
    `máximo real ${pt(Math.max(...iphDaMacro3529), 1)}%`,
  )
})
test('renderiza a série regional persistida com competência, amostra e denominador', async ({ page }) => {
  await mockLiveSource(page)
  await page.route('**/api/dev/v1/regioes/resumo**', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...regionalSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })

  await page.goto(`/regional?competencia=${snapshotCompetencia}&regiao=35073`)

  await expect(page.getByRole('heading', { name: 'Série de JUNDIAI' })).toBeVisible()
  await expect(page.getByTestId('regional-series-chart')).toBeVisible()
  await expect(page.getByTestId('regional-series-current')).toContainText(`${snapshotCompetenciaBR} · IPH estimado`)
  await expect(page.getByTestId('regional-series-current')).toContainText(
    `${pt(serieRegionalAtual.iph_percent as number, 1)}%`,
  )
  await expect(page.getByTestId('regional-series-current')).toContainText(
    `${pt(serieRegionalAtual.estimated_patient_days as number)} pacientes-dia / ` +
      `${pt(serieRegionalAtual.declared_capacity_bed_days as number)} leitos-dia declarados`,
  )

  await page.getByRole('radio', { name: 'TMH observado' }).click()
  await expect(page.getByTestId('regional-series-current')).toContainText(
    `${pt(serieRegionalAtual.tmh_percent as number, 1)}%`,
  )
  await expect(page.getByTestId('regional-series-current')).toContainText(
    `${pt(serieRegionalAtual.deaths as number)} óbitos · ` +
      `${pt(serieRegionalAtual.new_admissions as number)} internações`,
  )

  const currentPoint = page.getByTestId(`regional-series-point-${snapshotCompetencia}`)
  await currentPoint.hover()
  const tooltip = page.getByRole('tooltip')
  await expect(tooltip).toContainText(`${snapshotCompetenciaBR} · TMH observado`)
  await expect(tooltip).toContainText(`${pt(serieRegionalAtual.tmh_percent as number, 1)}%`)
  await expect(tooltip).toContainText(
    `${pt(serieRegionalAtual.deaths as number)} óbitos · ` +
      `${pt(serieRegionalAtual.new_admissions as number)} internações`,
  )
  await currentPoint.focus()
  await currentPoint.press('Escape')
  await expect(tooltip).not.toBeVisible()

  // O IPE entrou no seletor da série: a evolução mensal é onde se vê se a
  // permanência ante os pares vem piorando ou é do mês.
  await page.getByRole('radio', { name: 'Ante os pares (IPE)' }).click()
  await expect(page.locator('#regional-series-chart-title')).toContainText(
    'Ante os pares (IPE)',
  )

  const details = page.locator('.series-values-details')
  await expect(details.locator('summary')).toContainText(
    `6 de ${paginacao(regionalSeriesSnapshot).count}`,
  )
  await details.locator('summary').click()
  await expect(details.locator('tbody tr')).toHaveCount(6)
  await details
    .getByRole('button', {
      name: `Ver todas as ${paginacao(regionalSeriesSnapshot).count} competências`,
    })
    .click()
  await expect(details.locator('tbody tr')).toHaveCount(paginacao(regionalSeriesSnapshot).count)
})
test('explica pelo contrato quando a sazonalidade não é calculada', async ({ page }) => {
  await mockLiveSource(page)
  const items = regionalSnapshot.items as Array<Record<string, unknown>>
  await page.route('**/api/dev/v1/regioes/resumo**', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...regionalSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
        data_through: '2024-03',
        filters: {
          year: 2024,
          month: 3,
          macroregion_code: null,
          region_code: null,
        },
        items: items.map((item, index) =>
          index === 0
            ? {
                ...item,
                seasonality_index: null,
                seasonal_variation_percent: null,
                seasonality_status: 'fora_periodo_alvo',
                historical_years: 2,
              }
            : item,
        ),
      }),
    })
  })

  await page.goto('/regional?competencia=2024-03&regiao=35073')

  // A explicação mudou de lugar, não de exigência: ela vive na série mensal,
  // ao lado da curva que qualifica. Dizer só "não calculado" trataria fora do
  // período-alvo e histórico insuficiente como a mesma coisa.
  await page.getByRole('radio', { name: 'Índice sazonal' }).click()
  await expect(page.getByTestId('regional-series-current')).toContainText(
    'Competência fora do período-alvo definido para sazonalidade',
  )
})
test('mantém a metodologia colapsável', async ({ page }) => {
  await mockLiveSource(page)
  await page.route('**/api/dev/v1/regioes/resumo**', async (route) => {
    await route.fulfill({
      contentType: 'application/json',
      body: JSON.stringify({
        ...regionalSnapshot,
        source: 'oracle-live',
        database_time: '2026-08-01T12:00:00-03:00',
      }),
    })
  })

  await page.goto('/regional?regiao=35073')

  await page.getByRole('link', { name: 'Metodologia' }).click()
  await expect(page).toHaveURL(/\/metodologia(\?|$)/)

  // O IPE presta contas da própria cobertura no mesmo lugar que os demais: os
  // elegíveis sobre o total de linhas hospital/especialidade, e a fórmula e o
  // corte declarados ao lado dos do IPR.
  await expect(page.getByTestId('coverage-eligible-ipe')).toContainText(
    pt((methodologySnapshot.coverage as Record<string, number>).eligible_ipe_rows),
  )
  // A fórmula mora num bloco colapsado: conferimos que ela existe, não que
  // esteja aberta.
  await expect(
    page.getByText('permanência média hospital/especialidade', { exact: false }),
  ).toHaveCount(1)

  // Cinco, não seis: reconciliação e limites subiram para blocos visíveis, e
  // cortes absorveu os estados de ausência, que são o mesmo assunto visto dos
  // dois lados.
  const details = page.locator('.methodology-details details')
  await expect(details).toHaveCount(5)
  await expect(details.first()).not.toHaveAttribute('open', '')
  await details.first().locator('summary').click()
  const detailHeight = await details.first().locator('.detail-scroll').evaluate(
    (element) =>
      (element as unknown as { getBoundingClientRect: () => { height: number } })
        .getBoundingClientRect().height,
  )
  expect(detailHeight).toBeLessThanOrEqual(0.45 * 720 + 1)
})

test('a escala do placar usa a rampa inteira, do melhor ao pior do recorte', async ({ page }) => {
  await mockLiveSource(page)
  await page.goto(`/?competencia=${snapshotCompetencia}`)
  await expect(page.locator('.regional-map-shape')).toHaveCount(62)

  // Os cortes eram fixos em 0, 1, 2 e 3. Como o recorte publicado chega no
  // máximo a 3 dos 6 sinais, os dois tons escuros nunca apareciam: o mapa
  // inteiro ficava na metade clara, e a legenda exibia um tom que região
  // nenhuma tinha. Sem o tom mais escuro em uso, "quem é o pior" não se vê.
  await expect(page.locator('.regional-map-shape.tone-1').first()).toBeVisible()
  await expect(page.locator('.regional-map-shape.tone-5').first()).toBeVisible()
})

test('o mapa pode colorir pelo placar que consome os seis indicadores', async ({ page }) => {
  await mockLiveSource(page)
  await page.goto(`/?competencia=${snapshotCompetencia}`)

  // O padrão é o placar: ele é o que responde "onde olhar primeiro", enquanto
  // o IPH sozinho é um dos seis sinais que ele conta.
  await expect(page.locator('#map-title')).toContainText('Sinais acesos')
  await expect(page.getByTestId('regional-map-legend')).toContainText('sinais')
  await expect(page.getByTestId('regional-map-legend')).toContainText(
    'não nota de qualidade',
  )

  await page.getByTestId('map-metric-iph').click()
  await expect(page.locator('#map-title')).toContainText('IPH estimado')
  await expect(page.getByTestId('regional-map-legend')).toContainText('mínimo real')

  await page.getByTestId('map-metric-sinais').click()
  await expect(page.locator('#map-title')).toContainText('Sinais acesos')
})

test('a metodologia responde as duas metades do proprio titulo', async ({ page }) => {
  await mockLiveSource(page)
  await page.goto('/metodologia')

  // "Posso confiar no número e quais são seus limites?" — a reconciliação e as
  // limitações respondem uma metade cada, e estavam as duas colapsadas, uma
  // delas a dois cliques. O que ficou colapsado é material de consulta.
  await expect(page.getByTestId('reconciliation-patient_days_cross_mart')).toBeVisible()
  await expect(page.getByTestId('reconciliation-patient_days_cross_mart')).toContainText(
    'diferença: 0',
  )
  await expect(page.getByTestId('methodology-limits')).toBeVisible()
  await expect(page.getByTestId('methodology-limits')).toContainText('sem ajuste de risco')

  // O texto da metodologia vem do banco, e chegava inteiro sem acento.
  const prosa = await page.getByTestId('methodology-limits').innerText()
  expect(prosa).toContain('clínico')
  expect(prosa).not.toContain('clinico')
})
